
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder, MinMaxScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# Load the new dataset
file_path = 'checkpoint5_neighbourhood_district_data.csv'
df = pd.read_csv(file_path)

# Define additional features
df['is_weekend'] = pd.to_datetime(df['datetime']).dt.weekday >= 5

# Define features and target variable
features = df[['icon', 'moon_phase', 'neighbourhood_bcn', 'precipitation', 'visibility', 'cloud_cover', 'snow', 'temp', 'is_weekend']]
target = df['estimated_occupancy_rate']

# Drop rows with missing values in the selected columns
df = df[features.columns.tolist() + [target.name]].dropna()

# Normalize data
scaler = MinMaxScaler()
df[['precipitation', 'visibility', 'cloud_cover', 'snow', 'temp']] = scaler.fit_transform(df[['precipitation', 'visibility', 'cloud_cover', 'snow', 'temp']])

# Define weights for weighted average
weights = {'estimated_occupancy_rate': 0.5, 'precipitation': 0.15, 'visibility': 0.1, 'cloud_cover': 0.1, 'is_weekend': 0.1, 'snow': 0.1, 'temp': 0.1}

# Calculate weighted average for estimated occupancy rate
df['weighted_occupancy'] = (
    df['estimated_occupancy_rate'] * weights['estimated_occupancy_rate'] +
    df['precipitation'] * weights['precipitation'] +
    df['visibility'] * weights['visibility'] +
    df['cloud_cover'] * weights['cloud_cover'] +
    df['is_weekend'] * weights['is_weekend'] +
    df['snow'] * weights['snow'] +
    df['temp'] * weights['temp']
)

# Define features and target variable for model training
features = df[['icon', 'moon_phase', 'neighbourhood_bcn', 'weighted_occupancy']]
target = df['estimated_occupancy_rate']

# Split the data into training and testing sets
X = df[features.columns]
y = df[target.name]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Preprocessing for numerical and categorical features
numeric_features = ['weighted_occupancy']
numeric_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())])

categorical_features = ['icon', 'moon_phase', 'neighbourhood_bcn']
categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)])

# Append regressor to preprocessing pipeline
model = Pipeline(steps=[('preprocessor', preprocessor),
                        ('regressor', RandomForestRegressor(n_estimators=100, random_state=42))])

# Train the model
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

mse, r2

# Define the arrival and departure rates
lambda_rate = 0.05  # example value, can be adjusted based on historical data
mu_rate = 0.03      # example value, can be adjusted based on historical data
time_interval = 1   # for example, 1 hour

# Calculate future occupancy (N_{t+h})
current_occupancy = y_pred
future_occupancy = current_occupancy + (lambda_rate - current_occupancy * mu_rate) * time_interval

# Calculate expected occupancy over time (E_t)
initial_occupancy = current_occupancy[0]  # Assuming the first value as the initial occupancy
expected_occupancy = np.exp(-mu_rate * time_interval) * (initial_occupancy - lambda_rate / mu_rate) + lambda_rate / mu_rate

# Calculate probabilities based on the expected occupancy per row
expected_occupancy_per_row = np.exp(-mu_rate * time_interval) * (current_occupancy - lambda_rate / mu_rate) + lambda_rate / mu_rate

# Calculate probabilities based on the expected occupancy per row
probabilities_per_row = 1 - np.exp(-expected_occupancy_per_row)

# Create a DataFrame with the probabilities
probabilities_df_corrected = pd.DataFrame({
    'icon': X_test['icon'],
    'moon_phase': X_test['moon_phase'],
    'neighbourhood_bcn': X_test['neighbourhood_bcn'],
    'weighted_occupancy': X_test['weighted_occupancy'],
    'Predicted_Occupancy_Rate': future_occupancy,
    'Expected_Occupancy': expected_occupancy_per_row,
    'Probability': probabilities_per_row
})

probabilities_df_corrected

# Save the preprocessor
preprocessor_filename = 'preprocessor.pkl'
joblib.dump(preprocessor, preprocessor_filename)

# Save the model
model_filename = 'model.pkl'
joblib.dump(model, model_filename)
